<?php

return [
    'title'       => 'Currencyconvertor',
    'name'        => 'Currencyconvertor Module',
    'description' => ''
];
