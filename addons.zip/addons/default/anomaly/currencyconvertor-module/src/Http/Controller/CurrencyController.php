<?php
/**
 * Created by PhpStorm.
 * User: Satish Khatri
 * Date: 27/11/2017
 * Time: 05:58 PM
 */

namespace Anomaly\CurrencyconvertorModule\Http\Controller;

use Anomaly\Streams\Platform\Http\Controller\PublicController;

class CurrencyController extends PublicController
{
    /**
     * load xml file
     * @return $this
     */
    public function index(){
        $xml = simplexml_load_file("http://www.floatrates.com/daily/gbp.xml");
        if (!$xml) {
            throw new Exception("Cannot load xml source.\n");
        }
        return $this->view->make('anomaly.module.currencyconvertor::home')->with('data', $xml->item);
    }

}