<?php namespace Anomaly\CurrencyconvertorModule\Test\Feature;

class CurrencyconvertorModuleTest extends \TestCase
{

    public function testFeature()
    {
        $this->markTestSkipped('Not implemented.');
    }
}
