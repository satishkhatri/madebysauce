<?php

return [
    'title'       => 'Madebysauce',
    'name'        => 'Madebysauce Theme',
    'description' => ''
];
