<?php namespace Satish\MadebysauceTheme;

use Anomaly\Streams\Platform\Addon\Theme\Theme;

class MadebysauceTheme extends Theme
{

}
