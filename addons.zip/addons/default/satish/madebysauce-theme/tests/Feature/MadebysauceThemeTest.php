<?php namespace Satish\MadebysauceTheme\Test\Feature;

class MadebysauceThemeTest extends \TestCase
{

    public function testFeature()
    {
        $this->markTestSkipped('Not implemented.');
    }
}
